﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Collections_Demo;
using Collections_Demo.Collections;

namespace Collections_Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            CGList<int> list = new CGList<int>(3);
            CGList<string> list2 = new CGList<string>(3);
            Console.WriteLine($"Collection Capacity : {list.Capacity}, Count : {list.Count}");

            list.Add(1);
            Console.WriteLine($"Collection Capacity : {list.Capacity}, Count : {list.Count}");
            list.Add(2);
            Console.WriteLine($"Collection Capacity : {list.Capacity}, Count : {list.Count}");
            list.Add(3);
            Console.WriteLine($"Collection Capacity : {list.Capacity}, Count : {list.Count}");
            list.Add(4);
            Console.WriteLine($"Collection Capacity : {list.Capacity}, Count : {list.Count}");

            //for (int i = 0; i < list.Count; i++)
            //{
            //    Console.Write($"{list[i]}, ");
            //}

            //use foreach for faster execution
            foreach (object element in list)
            {
                if (element != null)
                {
                    Console.Write($"{element}, ");
                }
            }

            //same code but using arraylist
            //ArrayList list = new ArrayList(3);
            //list.Add(1);
            //Console.WriteLine($"Collection Capacity : {list.Capacity}, Count : {list.Count}");
            //list.Add(2);
            //Console.WriteLine($"Collection Capacity : {list.Capacity}, Count : {list.Count}");
            //list.Add("Three");
            //Console.WriteLine($"Collection Capacity : {list.Capacity}, Count : {list.Count}");
            //list.Add(4.66d);
            //Console.WriteLine($"Collection Capacity : {list.Capacity}, Count : {list.Count}");

            ////for (int i = 0; i < list.Count; i++)
            ////{
            ////    Console.Write($"{list[i]}, ");
            ////}
            //int sum = 0;
            //foreach(object element in list)
            //{
            //    Console.Write($"{element}, ");
            //    sum += Convert.ToInt32(element);
            //}

            //list for a specific datatype (generic)
            //List<int> list = new List<int>(3);
            //list.Add(1);
            //Console.WriteLine($"Collection Capacity : {list.Capacity}, Count : {list.Count}");
            //list.Add(2);
            //Console.WriteLine($"Collection Capacity : {list.Capacity}, Count : {list.Count}");
            //list.Add(3);
            //Console.WriteLine($"Collection Capacity : {list.Capacity}, Count : {list.Count}");
            //list.Add(4);
            //Console.WriteLine($"Collection Capacity : {list.Capacity}, Count : {list.Count}");

            //int sum = 0;
            //foreach (object element in list)
            //{
            //    Console.Write($"{element}, ");
            //    sum += Convert.ToInt32(element);
            //}
            //Console.Write($"The Sum is : {sum}");

            //add elements using stack
            //Stack<int> stk = new Stack<int>(3); //generic stack
            //Stack stk = new Stack();
            //stk.Push(10);
            //stk.Push(20);
            //stk.Push("Three");
            //stk.Push(4.2455d);

            //Console.WriteLine($"The Count is : {stk.Count}");
            //while (stk.Count > 0)
            //{
            //    Console.Write($"{stk.Pop()}, ");
            //}

            //add elements using queue
            //Queue<int> stk = new Queue<int>(3); //generic queue
            //Queue q = new Queue();
            //q.Enqueue(10);
            //q.Enqueue(20);
            //q.Enqueue("Three");
            //q.Enqueue(4.2455d);

            //Console.WriteLine($"The Count is : {q.Count}");
            //while (q.Count > 0)
            //{
            //    Console.Write($"{q.Dequeue()}, ");
            //}

            //hashtable
            //Dictionary<string, int> ht = new Dictionary<string, int>(3);  //generic hashtable
            //Hashtable ht = new Hashtable();
            //ht.Add("One",1);
            //ht.Add("Two",2);
            //ht.Add("Three",3);
            //ht.Add("Four",4);
            //ht.Add("Five",5);
            //Console.Write($"Count is : {ht.Count}, ");

            //foreach (string key in ht.Keys)
            //{
            //    Console.Write($"{ht[key]}, ");
            //}

            //sorted list
            //SortedDictionary<string, int> sd = new SortedDictionary<string, int>(); //generic
            //SortedList ht = new SortedList();
            //ht.Add("One", 1);
            //ht.Add("Two", 2);
            //ht.Add("Three", 3);
            //ht.Add("Four", 4);
            //ht.Add("Five", 5);
            //Console.Write($"Count is : {ht.Count}, ");

            //foreach (string key in ht.Keys)
            //{
            //    Console.Write($"{ht[key]}, ");
            //}

            Console.ReadKey();
        }
    }
}
