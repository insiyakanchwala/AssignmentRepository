﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collections_Demo.Collections
{
    //public class CGList
    //{
    //    private object[] store;
    //    private int count;

    //    public CGList(int initialCapacity)
    //    {
    //        store = new object[initialCapacity];
    //        count = 0;
    //    }

    //    public int Count 
    //    {
    //        get { return count; } 
    //    }

    //    public int Capacity
    //    {
    //        get { return store.Length; }
    //    }

    //    public void Add(object element) 
    //    {
    //        if (Count == Capacity)
    //        {
    //            Array.Resize<object>(ref store, Count * 2);
    //        }
    //        store[count++] = element;
    //    }

    //    //indexer (type indexer and tab twice)
    //    public object this[int index]
    //    {
    //        get 
    //        {
    //            /* return the specified index here */
    //            if (index >= 0 && index < Count)
    //            {
    //                return store[index];
    //            }
    //            else
    //            {
    //                throw new IndexOutOfRangeException($"Element at {index} does not exist.");
    //            }
    //        }
    //        set 
    //        { /* set the specified index to value here */
    //            if (index >= 0 && index < Count)
    //            {
    //                store[index] = value;
    //            }
    //            else
    //            {
    //                throw new IndexOutOfRangeException($"Element at {index} is not possible.");
    //            }
    //        }
    //    }

    //    public IEnumerator GetEnumerator()
    //    {
    //        foreach (object element in store)
    //        {
    //            yield return element; //iterator runs untill null reference
    //        }
    //    }
    //}

    public class CGList<TElement> where TElement : class
    {
        private TElement[] store;
        private int count;

        public CGList(int initialCapacity)
        {
            store = new TElement[initialCapacity];
            count = 0;
        }

        public int Count
        {
            get { return count; }
        }

        public int Capacity
        {
            get { return store.Length; }
        }

        public void Add(TElement element)
        {
            if (Count == Capacity)
            {
                Array.Resize<TElement>(ref store, Count * 2);
            }
            store[count++] = element;
        }

        //indexer (type indexer and tab twice)
        public TElement this[int index]
        {
            get
            {
                /* return the specified index here */
                if (index >= 0 && index < Count)
                {
                    return store[index];
                }
                else
                {
                    throw new IndexOutOfRangeException($"Element at {index} does not exist.");
                }
            }
            set
            { /* set the specified index to value here */
                if (index >= 0 && index < Count)
                {
                    store[index] = value;
                }
                else
                {
                    throw new IndexOutOfRangeException($"Element at {index} is not possible.");
                }
            }
        }

        public IEnumerator<TElement> GetEnumerator()
        {
            foreach (TElement element in store)
            {
                yield return element; //iterator runs untill null reference
            }
        }
    }
}
